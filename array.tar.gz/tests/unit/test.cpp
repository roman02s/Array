#include "Array.hpp"

#include <string>
#include <vector>
#include <gtest/gtest.h>

TEST(ArrayTest, CreateNullSize) {
    Array<int> numbers;
    Array<bool> test;
    Array<char> word;
    Array<std::string> sentence;
    ASSERT_EQ(numbers.size(), 0);
    ASSERT_EQ(test.size(), 0);
    ASSERT_EQ(word.size(), 0);
    ASSERT_EQ(sentence.size(), 0);
    sentence.clear();
    word.clear();
    test.clear();
    numbers.clear();
}

TEST(ArrayTest, Create) {
    Array<int> numbers(10);
    Array<bool> test(5);
    Array<char> word(4);
    Array<std::string> sentence(30);
    ASSERT_EQ(numbers.size(), 10);
    ASSERT_EQ(test.size(), 5);
    ASSERT_EQ(word.size(), 4);
    ASSERT_EQ(sentence.size(), 30);
    sentence.clear();
    word.clear();
    test.clear();
    numbers.clear();
}

TEST(ArrayTest, GetSet) {
    Array<int> numbers(10);
    numbers[0] = 10;
    ASSERT_EQ(numbers[0], 10);
    numbers.clear();
}

TEST(ArrayTest, Resize) {
    Array<std::string> names(10);
    ASSERT_EQ(names.size(), 10);
    names.resize(5);
    ASSERT_EQ(names.size(), 5);
}

TEST(ArrayTest, Iterator) {
    Array<std::string> names(10);
    for(std::string &name: names)
        name = "Петя";
}



TEST(ArrayTest, Filling) {
    Array<std::string> names(10);
    int k = 0;
    for(std::string &name: names)
        name = "Петя" + std::to_string(k++);

    ASSERT_TRUE(names.size() == 10);
    k = 0;
    for(const std::string &name: names)
        ASSERT_TRUE(name == "Петя" + std::to_string(k++));
}


TEST(ArrayTest, Sort) {
    Array<std::string> names(10);
    int k = 0;
    for(std::string &name: names) {
        name = "Петя" + std::to_string(10 - k++ - 1);
        std::cout << name << '\n';
    }
    std::cout << '\n';
    ASSERT_TRUE(names.size() == 10);
    names.sort([&](std::string &a, std::string &b) {return a < b;});

    k = 0;
    for(const std::string &name: names) {
        ASSERT_TRUE(name == "Петя" + std::to_string(k++));
        std::cout << name << '\n';
    }
}