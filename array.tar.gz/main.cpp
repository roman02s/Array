#include <iostream>
#include <cstdlib>
#include <algorithm>

#include "Array.hpp"

int main() {
	Array<int> arr(10);
    for(int & i : arr)
        i = rand() % 10;

    //минимум
    int* _min = arr.find_element([](int a, int b) { return (a < b); });
    if(_min != arr.end())
        std::cout << "min: " << *_min << std::endl;
 
    //максимум
    int* _max = arr.find_element([](int a, int b) { return (a > b); });
    if(_max != arr.end())
        std::cout << "max: " << *_max << std::endl;
 
    //сортируем по возрастанию
    arr.sort([] (int a, int b) { return (a < b); });
    for(int i : arr)
        std::cout << i << ' ';
    std::cout << std::endl;
 
    //сортируем по убыванию
    arr.sort([] (int a, int b) { return (a > b); });
    for(int i : arr)
        std::cout << i << ' ';

    std::cout << '\n';
    std::for_each(arr.cbegin(), arr.cend(), [](int x) {
        std::cout << x << ' ';
    });
    arr.clear();
	return 0;
}